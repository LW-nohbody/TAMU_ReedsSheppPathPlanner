namespace DigSim3D.Domain;

public readonly record struct Pose(double X, double Z, double Yaw);