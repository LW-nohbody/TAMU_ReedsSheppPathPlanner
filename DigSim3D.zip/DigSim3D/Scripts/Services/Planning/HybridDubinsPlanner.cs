using Godot;
using System;
using System.Collections.Generic;
using System.Linq;
using DigSim3D.App;
using DigSim3D.Domain;

namespace DigSim3D.Services
{
    /// <summary>
    /// Hybrid path planner that first tries a Dubins path.
    /// If blocked, it computes an A* grid path and then stitches
    /// collision-free D segments through key A* waypoints.
    /// </summary>
    public sealed class HybridDubinsPlanner : IPathPlanner
    {
        private readonly float _sampleStep;
        private readonly float _gridSize;
        private readonly int _gridExtent;
        private readonly float _obstacleBuffer;
        private readonly int _maxAttempts;

        public HybridDubinsPlanner(
            float sampleStepMeters = 0.25f,
            float gridSize = 0.25f,
            int gridExtent = 60,
            float obstacleBufferMeters = 0.5f,
            int maxAttempts = 2000)
        {
            _sampleStep = sampleStepMeters;
            _gridSize = gridSize;
            _gridExtent = gridExtent;
            _obstacleBuffer = obstacleBufferMeters;
            _maxAttempts = maxAttempts;
        }

        /// <summary>
        /// Plans the Dubins path, starts with seeing if Dubins can reach goal. If not calls replanning function.
        /// </summary>
        public PlannedPath Plan(Pose start, Pose goal, VehicleSpec spec, WorldState world)
        {
            var startPos = new Vector3((float)start.X, 0, (float)start.Z);
            var goalPos = new Vector3((float)goal.X, 0, (float)goal.Z);

            var obstacles = world?.Obstacles?.OfType<CylinderObstacle>().ToList() ?? new List<CylinderObstacle>();

            // Get arena radius for wall boundary checking
            float arenaRadius = world?.Terrain?.Radius ?? float.PositiveInfinity;

            // 1️⃣ Direct Dubins path
            double r = Math.Sqrt(goalPos.X * goalPos.X + goalPos.Z * goalPos.Z);
            double d = arenaRadius - r;
            float angleToWall = MathF.Atan2(goalPos.Z, goalPos.X);
            float angleWallDiff = angleToWall - (float)goal.Yaw;
            float angleWallDist = MathF.Atan2(MathF.Sin(angleWallDiff), MathF.Cos(angleWallDiff));

            if (Math.Abs(angleWallDist) < 0.48 && d < spec.TurnRadius + 0.75)
            {
                // GD.Print("[HybridDubinsPlanner] Reassigning goal orientation to avoid wall");
                var yawSign = angleWallDiff / Math.Abs(angleWallDiff);
                goal = new Pose(goal.X, goal.Z, angleToWall - yawSign * 0.48f);
            }

            var (dPoints, dGears) = DAdapter.ComputePath3D(
                startPos, start.Yaw,
                goalPos, goal.Yaw,
                turnRadiusMeters: spec.TurnRadius,
                fieldRadius: arenaRadius,
                sampleStepMeters: _sampleStep
            );

            var dPts = dPoints.ToList();
            if (obstacles.Count == 0 || PathIsValid(dPts, obstacles, goal.Yaw, spec.TurnRadius, arenaRadius))
            {
                return BuildPath(dPts, dGears.ToList());
            }

            // Dubins path is blocked — start replanning
            var gridPath = GridPlannerPersistent.Plan2DPath(startPos, goalPos);

            // Always show grid visualization for debugging
            DrawDebugGridAndPath(GridPlannerPersistent.LastBlockedCenters, gridPath, _gridSize, _gridExtent);

            if (gridPath == null || gridPath.Count < 3)
            {
                GD.PrintErr("[HybridDubinsPlanner] A* grid path failed — returning fallback Dubins.");
                return BuildPath(dPts, dGears.ToList());
            }

            // Attempt to replan
            var merged = TryReplanWithMidpoints(
                startPos,
                goalPos,
                spec.TurnRadius,
                gridPath,
                obstacles,
                startGear: 1,
                world: world,
                goalYaw: goal.Yaw,
                startYaw: start.Yaw,
                arenaRadius: arenaRadius
            );

            if (merged.points != null && merged.gears != null)
            {
                // GD.Print($"✅ Hybrid replanning succeeded — {merged.points.Count} points total.");
                return BuildPath(merged.points, merged.gears);
            }

            GD.PrintErr("❌ Could not find clear D route via midpoints. Returning fallback D path.");
            return BuildPath(dPts, dGears.ToList());
        }

        /// <summary>
        /// Replans Dubins path around obstacles by stitching together valid Dubins paths to A* subgoals.
        /// If subgoals can't be reached it subdivides the path until a new A* subgoal can be reached
        /// </summary>
        private (List<Vector3>? points, List<int>? gears) TryReplanWithMidpoints(
            Vector3 start,
            Vector3 goal,
            double turnRadius,
            List<Vector3>? gridPath,
            List<CylinderObstacle> obstacles,
            int startGear,
            WorldState? world,
            double goalYaw,
            double startYaw,
            float arenaRadius)
        {
            if (gridPath == null || gridPath.Count < 2)
                return (null, null);

            // --- 1️⃣ Simplify the A* path (remove nearly-collinear points) ---
            var simplifiedPath = new List<Vector3> { gridPath[0] };
            var temp = gridPath[0];
            simplifiedPath[0] = temp;
            const float angleThreshold = 5f * (float)(Math.PI / 180.0);

            for (int i = 1; i < gridPath.Count - 1; i++)
            {
                Vector3 prev = simplifiedPath.Last();
                Vector3 curr = gridPath[i];
                Vector3 next = gridPath[i + 1];
                Vector3 v1 = (curr - prev).WithY(0).Normalized();
                Vector3 v2 = (next - curr).WithY(0).Normalized();
                float angle = (float)Math.Acos(Math.Clamp(v1.Dot(v2), -1f, 1f));
                if (Math.Abs(angle) > angleThreshold)
                {
                    simplifiedPath.Add(curr);
                }
            }

            temp = gridPath[^1];
            simplifiedPath.Add(temp);

            // --- 2️⃣ Build initial D path along simplified path ---
            var mergedPoints = new List<Vector3> { start };
            var mergedGears = new List<int> { startGear };
            double prevYaw = startYaw;

            int index = 0;

            while (index < simplifiedPath.Count)
            {
                Vector3 segStart = mergedPoints.Last();
                int farthestReachable = index;
                bool AStarValid = false;
                bool nonShortestPath = false;
                Vector3[]? nextBestPath = null;

                // Try skipping as many A* points as possible
                for (int j = simplifiedPath.Count - 1; j >= index; j--)
                {
                    Vector3 segEnd = simplifiedPath[j];
                    double segYaw = 0.0;
                    if (j == simplifiedPath.Count - 1)
                    {
                        segYaw = goalYaw;
                    }
                    else
                    {
                        segYaw = Math.Atan2((segEnd - segStart).Z, (segEnd - segStart).X);
                    }

                    var (dTest, dTestGears) = DAdapter.ComputePath3D(
                        segStart,
                        prevYaw,
                        segEnd,
                        segYaw,
                        turnRadius,
                        arenaRadius,
                        _sampleStep
                    );

                    if (dTest.Length == 0 || !PathIsValid(dTest.ToList(), obstacles, segYaw, turnRadius, arenaRadius))
                    {
                        // If shortest path cannot reach, check all other Dubins paths
                        var (dTests, dTestsGears) = DAdapter.ComputeAllPath3D(
                            segStart,
                            prevYaw,
                            segEnd,
                            segYaw,
                            turnRadius,
                            arenaRadius,
                            _sampleStep
                        );

                        foreach (var test in dTests)
                        {
                            if (test.Length > 0 && PathIsValid(test.ToList(), obstacles, segYaw, turnRadius, arenaRadius))
                            {
                                farthestReachable = j;
                                AStarValid = true;
                                nonShortestPath = true;
                                nextBestPath = test;
                                break;
                            }
                        }
                    }
                    else
                    {
                        farthestReachable = j;
                        AStarValid = true;
                        nonShortestPath = false;
                        break;
                    }
                }

                Vector3 target = simplifiedPath[farthestReachable];
                double targetYaw = 0.0;
                int nextIdx = Math.Min(farthestReachable + 1, simplifiedPath.Count - 1);
                if (farthestReachable == simplifiedPath.Count - 1)
                {
                    targetYaw = goalYaw;
                }
                else
                {
                    Vector3 nextDirVec = target - segStart;
                    targetYaw = Math.Atan2(nextDirVec.Z, nextDirVec.X);
                }

                // Get Dubins path to the nearest reachable A* point, angled to follow the rest of A*
                var (dSegment, dGears) = DAdapter.ComputePath3D(
                    segStart,
                    prevYaw,
                    target,
                    targetYaw,
                    turnRadius,
                    arenaRadius,
                    _sampleStep
                );

                if (nonShortestPath)
                {
                    dSegment = nextBestPath!; // we only set nonShortestPath when nextBestPath is non-null
                    nonShortestPath = false;
                }

                // If path to next A* point isn't valid, split path into multiple Dubins paths up to 3 times
                int subdiv = 0;
                while (!AStarValid && subdiv < 3)
                {
                    bool pathFound = false;

                    subdiv++;
                    Vector3 mid = segStart.Lerp(target, 0.5f);

                    double midYaw = Math.Atan2((mid - segStart).Z, (mid - segStart).X); // TODO: refine so midYaw follows rest of path
                    double distToMid = Math.Sqrt(
                        (mid.X - segStart.X) * (mid.X - segStart.X) +
                        (mid.Z - segStart.Z) * (mid.Z - segStart.Z)
                    );

                    double maxYaw = distToMid / arenaRadius;
                    double yawDiff = Math.Max(-Math.PI, Math.Min(Math.PI, midYaw - prevYaw));
                    if (Math.Abs(yawDiff) > maxYaw)
                    {
                        GD.PrintErr("[HybridDubinsPlanner] Exceeded max yaw");
                        midYaw = prevYaw + (yawDiff / Math.Abs(yawDiff) * Math.Min(Math.Abs(yawDiff), maxYaw));
                    }

                    var (listD1, listD1Gears) = DAdapter.ComputeAllPath3D(
                        segStart,
                        prevYaw,
                        mid,
                        midYaw,
                        turnRadius,
                        arenaRadius,
                        _sampleStep
                    );

                    for (int idx = 0; idx < listD1.Length; idx++)
                    {
                        var d1 = listD1[idx];
                        if (d1.Length > 0 && PathIsValid(d1.ToList(), obstacles, midYaw, turnRadius, arenaRadius))
                        {
                            mergedPoints.AddRange(d1.Skip(1));
                            // NOTE: this assumes same indexing between listD1 and listD1Gears
                            mergedGears.AddRange(listD1Gears[idx].Skip(1));
                            pathFound = true;
                            break;
                        }
                    }

                    if (pathFound)
                    {
                        break;
                    }
                    else
                    {
                        GD.Print("[HybridDubinsPlanner] Subdivision failed");
                        target = mid;
                    }

                    prevYaw = targetYaw;
                }

                if (AStarValid)
                {
                    if (!PathIsValid(dSegment.ToList(), obstacles, targetYaw, turnRadius, arenaRadius))
                    {
                        GD.Print("[HybridDubinsPlanner] A*-based path is invalid");
                    }

                    mergedPoints.AddRange(dSegment.Skip(1));
                    mergedGears.AddRange(dGears.Skip(1));
                    if (dSegment.Length > 1)
                    {
                        var last = dSegment[^1];
                        var prevLast = dSegment[^2];
                        prevYaw = Math.Atan2((last - prevLast).Z, (last - prevLast).X);
                    }
                }

                index = farthestReachable + 1;
            }

            return (mergedPoints, mergedGears);
        }

        // ================================================================
        // ✅ Helpers
        // ================================================================
        private PlannedPath BuildPath(List<Vector3> pts, List<int> gears)
        {
            var path = new PlannedPath();
            path.Points.AddRange(pts);
            path.Gears.AddRange(gears);
            return path;
        }

        /// <summary>
        /// Checks if Dubins path is valid against obstacles and arena wall, also ensures that Dubins can escape from a position
        /// </summary>
        private bool PathIsValid(List<Vector3> pathPoints, List<CylinderObstacle> obstacles, double endYaw, double radius, float arenaRadius)
        {
            const float WallBufferMeters = 0.1f; // 0.1m wall buffer
            float maxAllowedRadius = arenaRadius - WallBufferMeters;

            foreach (var p in pathPoints)
            {
                // Check obstacle collisions
                foreach (var obs in obstacles)
                {
                    var dx = p.X - obs.GlobalPosition.X;
                    var dz = p.Z - obs.GlobalPosition.Z;
                    var distSq = dx * dx + dz * dz;
                    var minDist = obs.Radius + _obstacleBuffer;
                    var minDistSq = minDist * minDist;
                    double angleToObstacle = Math.Atan2(obs.GlobalPosition.Z - p.Z, obs.GlobalPosition.X - p.X);
                    double angleDist = Math.Abs(angleToObstacle - endYaw);
                    double turnDist = obs.Radius + radius;
                    double turnDistSq = turnDist * turnDist;

                    if (distSq < minDistSq || (angleDist < 0.48 && distSq < turnDistSq))
                    {
                        return false;
                    }
                }

                double r = Math.Sqrt(p.X * p.X + p.Z * p.Z);
                double d = arenaRadius - r;
                double angleToWall = Math.Atan2(p.Z, p.X);
                double angleWallDist = Math.Abs(angleToWall - endYaw);
                if (angleWallDist < 0.48 && d < radius)
                {
                    return false;
                }
            }

            return true;
        }

#if DEBUG
        /// <summary>
        /// For debugging purposes, will print the grid and path.
        /// </summary>
        private void DrawDebugGridAndPath(
            IReadOnlyList<Vector2>? blockedCenters,
            List<Vector3>? path3,
            float gridSize,
            int gridExtent)
        {
            var tree = Engine.GetMainLoop() as SceneTree;
            var scene = tree?.CurrentScene;
            if (scene == null)
                return;

            // Remove any previous debug geometry
            foreach (var child in scene.GetChildren())
            {
                if (child is Node n)
                {
                    var nm = n.Name.ToString();
                    if (nm.StartsWith("DebugGrid", StringComparison.Ordinal) ||
                        nm.StartsWith("DebugPath", StringComparison.Ordinal))
                        n.QueueFree();
                }
            }

            const float debugHeight = 1.0f; // 🔹 raise everything 1 meter above ground

            // --- Draw blocked grid cells (semi-transparent red) ---
            if (blockedCenters != null && blockedCenters.Count > 0)
            {
                var gridMeshInst = new MeshInstance3D { Name = "DebugGrid" };
                var gridIm = new ImmediateMesh();
                gridIm.SurfaceBegin(Mesh.PrimitiveType.Triangles);

                float half = gridSize * 0.45f;

                foreach (var c in blockedCenters)
                {
                    var a = new Vector3(c.X - half, debugHeight, c.Y - half);
                    var b = new Vector3(c.X + half, debugHeight, c.Y - half);
                    var c2 = new Vector3(c.X + half, debugHeight, c.Y + half);
                    var d = new Vector3(c.X - half, debugHeight, c.Y + half);

                    gridIm.SurfaceAddVertex(a);
                    gridIm.SurfaceAddVertex(b);
                    gridIm.SurfaceAddVertex(c2);
                    gridIm.SurfaceAddVertex(a);
                    gridIm.SurfaceAddVertex(c2);
                    gridIm.SurfaceAddVertex(d);
                }

                gridIm.SurfaceEnd();
                gridMeshInst.Mesh = gridIm;

                var matGrid = new StandardMaterial3D
                {
                    AlbedoColor = new Color(1, 0, 0, 0.35f),
                    Transparency = BaseMaterial3D.TransparencyEnum.Alpha,
                    ShadingMode = BaseMaterial3D.ShadingModeEnum.Unshaded
                };
                gridMeshInst.SetSurfaceOverrideMaterial(0, matGrid);
                scene.AddChild(gridMeshInst);
            }

            // --- Draw A* path (blue line) ---
            if (path3 != null && path3.Count > 1)
            {
                var pathMeshInst = new MeshInstance3D { Name = "DebugPath" };
                var im = new ImmediateMesh();
                im.SurfaceBegin(Mesh.PrimitiveType.LineStrip);

                foreach (var p in path3)
                    im.SurfaceAddVertex(new Vector3(p.X, debugHeight, p.Z));

                im.SurfaceEnd();
                pathMeshInst.Mesh = im;

                var matPath = new StandardMaterial3D
                {
                    AlbedoColor = new Color(0.0f, 0.5f, 1f),
                    ShadingMode = BaseMaterial3D.ShadingModeEnum.Unshaded
                };
                pathMeshInst.SetSurfaceOverrideMaterial(0, matPath);
                scene.AddChild(pathMeshInst);
            }
        }
#else
        private void DrawDebugGridAndPath(
            IReadOnlyList<Vector2>? blockedCenters,
            List<Vector3>? path3,
            float gridSize,
            int gridExtent)
        {
            // no-op in release
        }
#endif
    }
}