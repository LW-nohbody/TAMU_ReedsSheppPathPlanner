namespace SimCore.Core;
public readonly record struct Pose(double X, double Z, double Yaw);